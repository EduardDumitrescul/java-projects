import javax.swing.*;
import java.awt.*;

public class AlgorithmInfoPane extends JPanel {
    JTextPane textPane = new JTextPane();
    AlgorithmInfoPane() {
        add(textPane);
        textPane.setText("test");
    }
}
