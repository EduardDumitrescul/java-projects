import javax.swing.*;

public class ProjectInfoPane extends JPanel {
    private JTextArea textArea = new JTextArea();
    ProjectInfoPane() {
        add(textArea);
    }
}
